#include<iostream>
#include<cstdlib>
using namespace std;
void prog_3(int);
int main(void){
	int n;
	cout<<"Integer:";
	cin>>n;
	prog_3(n);
	cout<<endl;
	cout<<"Integer:";
	cin>>n;
	prog_3(n);
	return 0;
}

void prog_3(int num){
	//cout<<"Result:";
	//n2=num;
	int n1=0, n2=0, x=0;
	while(1){
		if(x==0){
			cout<<"Result:"<<num<<" ";
			n1=(num*num%1000)/10;
			cout<<n1<<" ";
			if(num==n1)
			break;
			x+=2;
		}
		if(x%2==0){
			n2=(n1*n1%1000)/10;
			cout<<n2<<" ";
			if(n1==n2)
			break;
			x++;
		}
	
		if(x%2!=0){
			n1=(n2*n2%1000)/10;
			cout<<n1<<" ";
			x++;
		}	
		if(n1==n2)
		break;
	}
}
