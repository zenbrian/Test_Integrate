#include<iostream>
#include<cstdlib>
using namespace std;
int main(void){
	int n, i, x=0;
	cout<<"Integer:";
	cin>>n;
	for(i=1;i<=50000;i=i*n){
		x++;
	}
	cout<<"Result:"<<x<<" "<<i<<endl;
	
	x=0;
	cout<<"Integer:";
	cin>>n;
	for(i=1;i<=50000;i=i*n){
		x++;
	}
	cout<<"Result:"<<x<<" "<<i;
}
