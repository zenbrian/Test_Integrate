#include<iostream>
#include<cstdlib>
using namespace std;
int main(void){
	int n, n1, n2;
	cout<<"Integer:";
	cin>>n;
	cout<<n<<" ";
	while(n1!=n)
	{
		n1=(n*n)%1000/100*10+(n*n)%100/10;
		cout<<n1<<" ";
		n=(n1*n1)%1000/100*10+(n1*n1)%100/10;
		cout<<n<<" ";
	}
}
