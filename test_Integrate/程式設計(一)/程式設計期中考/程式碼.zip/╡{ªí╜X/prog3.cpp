#include<iostream>
#include<cstdlib>
using namespace std;
int main(void){
	int a, b, i, j, x=1;
	cout<<"A:";
	cin>>a;
	cout<<"B:";
	cin>>b;
	cout<<"Result:"<<endl;
	for(i=0;i<a;i++){
		for(j=1;j<=b;j++){
			if(x%2!=0)
			cout<<"$";
			else
			cout<<"#";
		}
		x++;
		cout<<endl;
	}
	
	x=1;
	cout<<"A:";
	cin>>a;
	cout<<"B:";
	cin>>b;
	cout<<"Result:"<<endl;
	for(i=0;i<a;i++){
		for(j=1;j<=b;j++){
			if(x%2!=0)
			cout<<"$";
			else
			cout<<"#";
		}
		x++;
		cout<<endl;
	} 
}
