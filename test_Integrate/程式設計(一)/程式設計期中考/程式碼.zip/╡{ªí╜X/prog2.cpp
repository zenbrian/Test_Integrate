#include<iostream>
#include<cstdlib>
using namespace std;
int main(void){
	int m, n, i;
	float sum=0;
	cout<<"m:";
	cin>>m;
	cout<<"n:";
	cin>>n;
	if(m%2==0){
		for(i=m;i<=n;i++){
			if(i%2==0)
			sum=sum+(float)1/i;
			else
			sum=sum-(float)1/i;
		}
	cout<<"Result:"<<sum<<endl;
	}
	else{
		for(i=m;i<=n;i++){
			if(i%2!=0)
			sum=sum+(float)1/i;
			else
			sum=sum-(float)1/i;
		}
	cout<<"Result:"<<sum<<endl;
	}
	
	sum=0;
	cout<<"m:";
	cin>>m;
	cout<<"n:";
	cin>>n;
	if(m%2==0){
		for(i=m;i<=n;i++){
			if(i%2==0)
			sum=sum+(float)1/i;
			else
			sum=sum-(float)1/i;
		}
	cout<<"Result:"<<sum<<endl;
	}
	else{
		for(i=m;i<=n;i++){
			if(i%2!=0)
			sum=sum+(float)1/i;
			else
			sum=sum-(float)1/i;
		}
	cout<<"Result:"<<sum;
	}
}
