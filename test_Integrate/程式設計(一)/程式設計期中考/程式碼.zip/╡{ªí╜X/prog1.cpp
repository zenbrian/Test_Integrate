#include<iostream>
#include<cstdlib>
using namespace std;
int main(void){
	int m, n, i;
	cout<<"M:";
	cin>>m;
	cout<<"N:";
	cin>>n;
	if(m == n+n/100+n%100/10+n%100%10)
	cout<<"Yes"<<endl;
	else
	cout<<"No"<<endl;
	
	cout<<"M:";
	cin>>m;
	cout<<"N:";
	cin>>n;
	if(m == n+n/100+n%100/10+n%100%10)
	cout<<"Yes"<<endl;
	else
	cout<<"No"<<endl;
	
	cout<<"M:";
	cin>>m;
	cout<<"N:";
	cin>>n;
	if(m == n+n/100+n%100/10+n%100%10)
	cout<<"Yes";
	else
	cout<<"No";
}
