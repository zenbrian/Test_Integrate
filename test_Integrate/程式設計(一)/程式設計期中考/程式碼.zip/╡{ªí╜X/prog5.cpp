#include<iostream>
#include<cstdlib>
using namespace std;
int main(void){
	int n, i, x=0, j, N1, N2;
	cout<<"N:";
	cin>>n;
	for(i=n;i>1;i--){
		for(j=1;j<=n;j++){
			if(i%j==0)
			x++;
		}
		if(x==2){
		 N1=i;
		 break;
		}
		x=0;
	}
	x=0;
	for(i=n;i<1000;i++){
		for(j=1;j<1000;j++){
			if(i%j==0)
			x++;
		}
		if(x==2){
		 N2=i;
		 break;
		}
		x=0;
	}
	if(N2-n > n-N1)
	cout<<"Result:"<<N1<<endl;
	else
	cout<<"Result:"<<N2<<endl;
	
	x=0;
	cout<<"N:";
	cin>>n;
	for(i=n;i>1;i--){
		for(j=1;j<=n;j++){
			if(i%j==0)
			x++;
		}
		if(x==2){
		 N1=i;
		 break;
		}
		x=0;
	}
	
	x=0;
	for(i=n;i<1000;i++){
		for(j=1;j<1000;j++){
			if(i%j==0)
			x++;
		}
		if(x==2){
		 N2=i;
		 break;
		}
		x=0;
	}
	if(N2-n > n-N1)
	cout<<"Result:"<<N1;
	else
	cout<<"Result:"<<N2;
}
